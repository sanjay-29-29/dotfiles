vim.cmd("let g:netrw_liststyle=3")
 
local opt = vim.opt

opt.relativenumber = true
opt.number = true

--tabs
opt.tabstop = 2
opt.shiftwidth = 2
opt.expandtab = true
opt.autoindent = true

opt.colorcolumn = "80"
opt.wrap = true

--search
opt.ignorecase = true
opt.smartcase = true

--columnSize


--colors
opt.termguicolors = true
opt.background = "dark"
opt.signcolumn = "yes"

--backspace
opt.backspace = "indent,eol,start"

--clipboard
opt.clipboard:append("unnamedplus")
opt.clipboard='unnamedplus'
--split windows
opt.splitright = true
opt.splitbelow = true

